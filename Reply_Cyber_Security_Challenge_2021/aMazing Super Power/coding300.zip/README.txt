Oh no, this is a trap! The super power of coding has been shattered.
The only way to get out of the trap is to recover all the shards.
In each city of the file there is a fragment.
Beware though, you are weak and cannot use more than 58000 unit of energy.

Be careful that Zer0 will be waiting in Diagon Alley to ambush you. If Zer0 hits you, you have failed your mission so the only way to survive is to avoid him. Zer0 will only leave Diagon Alley, for 515 units of time, after 135 units of time since you started.
Zer0 cannot hit you outside Diagon Alley.

Zer0 has also made it so that after you have recovered the fragment the city becomes cursed: if you pass through this city again you will go back in time and everything will return as it was at the beginning.

When you have found all the shards return to the first city you visited. As soon as your foot lands on that first city all cities will be freed from the curse.
Recover all the shards and free all the city in the shortest time possible! Good luck!

The file (file.txt) specifies for each line the amount of time required and the amount of energy to go from city A to city B.
Each line is in the form:
<cityA>-<cityB>=<time>,<energy>

To open the zip file the password is in the form:
<time_spent_to_visit_cities>-yyy-<energy_spent>
where yyy is the concatenation of the first 2 letters of each city taken in the order you visited them.
So for example if you spent 10 unit of time and 15 unit of energy in an hypothetical path New York-London-Paris-New York the password will be:
10-NeLoPaNe-15